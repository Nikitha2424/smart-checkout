const firebaseConfig = {
  apiKey: "AIzaSyAk4mk1up7iRH2UPR5m61NBs16HyEtXrQg",
  authDomain: "smart-checkout-8fa5d.firebaseapp.com",
  databaseURL: "https://smart-checkout-8fa5d-default-rtdb.firebaseio.com",
  projectId: "smart-checkout-8fa5d",
  storageBucket: "smart-checkout-8fa5d.appspot.com",
  messagingSenderId: "312803902311",
  appId: "1:312803902311:web:dc9d2fb170b7e86fe425c2"
};
firebase.initializeApp(firebaseConfig);

const cart = JSON.parse(localStorage.getItem("cart")) || [];
const cartItems = document.getElementById("cartItems");
const totalDisplay = document.getElementById("total");
const qrContainer = document.getElementById("qrContainer");
const proceedToPay = document.getElementById("proceedToPay");

let totalAmount = 0;

function renderCart() {
  cartItems.innerHTML = "";
  totalAmount = 0;

  cart.forEach((item, index) => {
    totalAmount += item.price;

    const li = document.createElement("li");
    li.innerHTML = `
      ${item.name} - ₹${item.price}
      <button class="remove-btn" onclick="removeItem(${index})">❌</button>
    `;
    cartItems.appendChild(li);
  });

  totalDisplay.textContent = totalAmount;
}

function removeItem(index) {
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  renderCart();
}

proceedToPay.addEventListener("click", () => {
  if (totalAmount > 0) {
    qrContainer.innerHTML = "";

    const qr = new QRious({
      value: `upi://pay?pa=nikitha@upi&pn=SmartStore&am=${totalAmount}&cu=INR`,
      size: 200
    });

    const qrTitle = document.createElement("h3");
    qrTitle.textContent = "📱 Scan this QR to Pay";
    const qrImg = document.createElement("img");
    qrImg.src = qr.toDataURL();

    qrContainer.appendChild(qrTitle);
    qrContainer.appendChild(qrImg);

    const transactionRef = firebase.database().ref("transactions").push();
    const items = `cart.map(item => ${item.name} - ₹${item.price})`;
    transactionRef.set({
      amount: totalAmount,
      items: items,
      timestamp: new Date().toISOString()
    });

    localStorage.removeItem("cart");
    cartItems.innerHTML = "";
    totalDisplay.textContent = "0";
  } else {
    alert("❌ Your cart is empty!");
  }
});

renderCart();