// ✅ Firebase Config
const firebaseConfig = {
    apiKey: "AIzaSyAk4mklup7iRH2UPR5m6lNBsi6HyEtXrQg",
    authDomain: "smart-checkout-8fa5d.firebaseapp.com",
    databaseURL: "https://smart-checkout-8fa5d-default-rtdb.firebaseio.com",
    projectId: "smart-checkout-8fa5d",
    storageBucket: "smart-checkout-8fa5d.firebasestorage.app",
    messagingSenderId: "312803902311",
    appId: "1:312803902311:web:87d3333382c83403e425c2",
    measurementId: "G-JH29TKMR9P"
  };


// ✅ Initialize Firebase (ONLY ONCE)
firebase.initializeApp(firebaseConfig);

// ✅ HTML Elements
const productInput = document.getElementById("productCode");
const addToCartBtn = document.getElementById("addToCart");
const cartItems = document.getElementById("cartItems");
const totalDisplay = document.getElementById("total");
const goToCartBtn = document.getElementById("goToCart");

const loginEmail = document.getElementById("loginEmail");
const loginPassword = document.getElementById("loginPassword");
const loginBtn = document.getElementById("loginBtn");
const logoutBtn = document.getElementById("logoutBtn");

let cart = [];
let totalAmount = 0;

// ✅ Add to Cart
addToCartBtn?.addEventListener("click", () => {
  const code = productInput.value.trim().toUpperCase();
  if (!code) {
    alert("Please enter a product code.");
    return;
  }

  firebase.database().ref(code).once("value")
    .then(snapshot => {
      const product = snapshot.val();
      if (product) {
        cart.push({ code, name: product.name, price: product.price });
        updateCartUI();
        productInput.value = "";
      } else {
        alert("❌ Product not found.");
      }
    })
    .catch(err => alert("Error: " + err.message));
});

// ✅ Update Cart Display
function updateCartUI() {
  cartItems.innerHTML = "";
  totalAmount = 0;

  cart.forEach((item, index) => {
    totalAmount += item.price;
    const li = document.createElement("li");
    li.innerHTML = `
      ${item.name} - ₹${item.price}
      <button class="remove-btn" onclick="removeFromCart(${index})">❌</button>
    `;
    cartItems.appendChild(li);
  });

  totalDisplay.textContent = totalAmount;
}

// ✅ Remove from Cart
window.removeFromCart = function(index) {
  cart.splice(index, 1);
  updateCartUI();
};

// ✅ Go to Cart
goToCartBtn?.addEventListener("click", () => {
  localStorage.setItem("cart", JSON.stringify(cart));
  window.location.href = "cart.html";
});

// ✅ Admin Login
loginBtn?.addEventListener("click", () => {
  const email = loginEmail.value.trim();
  const password = loginPassword.value;

  if (!email || !password) {
    alert("Please enter both email and password.");
    return;
  }

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then(userCredential => {
      const user = userCredential.user;
      if (user.email === "adminwalmart@gmail.com") {
        alert("✅ Login Successful!");
        logoutBtn.style.display = "block";
        window.location.href = "addProduct.html";  // or dashboard.html
      } else {
        alert("❌ Unauthorized user.");
        firebase.auth().signOut();
      }
    })
    .catch(error => {
      alert("Login failed: " + error.message);
    });
});

// ✅ Admin Logout
logoutBtn?.addEventListener("click", () => {
  firebase.auth().signOut()
    .then(() => {
      alert("Logged out.");
      logoutBtn.style.display = "none";
    })
    .catch(error => {
      alert("Logout failed: " + error.message);
    });
});