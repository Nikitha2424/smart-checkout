// Initialize Firebase
const firebaseConfig = {
    apiKey: "AIzaSyAk4mk1up7iRH2UPR5m61NBs16HyEtXrQg",
  authDomain: "smart-checkout-8fa5d.firebaseapp.com",
  databaseURL: "https://smart-checkout-8fa5d-default-rtdb.firebaseio.com",
  projectId: "smart-checkout-8fa5d",
  storageBucket: "smart-checkout-8fa5d.appspot.com",
  messagingSenderId: "312803902311",
  appId: "1:312803902311:web:dc9d2fb170b7e86fe425c2",
  measurementId: "G-YNEPHNRGVT"

};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();

function loginAdmin() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  auth.signInWithEmailAndPassword(email, password)
    .then(() => {
      window.location.href = "dashboard.html";
    })
    .catch(error => {
      alert("Login Failed: " + error.message);
    });
}